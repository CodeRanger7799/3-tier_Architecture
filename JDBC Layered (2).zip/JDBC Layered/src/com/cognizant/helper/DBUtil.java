package com.cognizant.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBUtil {
	private static Connection connStudent;

	public static Connection createConnection() throws ClassNotFoundException,
			SQLException {
		ResourceBundle resMySql = ResourceBundle.getBundle("mysql");

		String url = resMySql.getString("url");
		String username = resMySql.getString("username");
		String password = resMySql.getString("password");
		String driver = resMySql.getString("driver");

		Class.forName(driver);

		connStudent = DriverManager.getConnection(url, username, password);

		return connStudent;
	}

	public static void closeConnection() throws SQLException {
		connStudent.close();
	}
}