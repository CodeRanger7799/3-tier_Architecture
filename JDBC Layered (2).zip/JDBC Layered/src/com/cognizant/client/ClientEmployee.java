package com.cognizant.client;

import java.util.List;

import com.cognizant.model.Employee;
import com.cognizant.service.EmployeeService;
import com.cognizant.service.EmployeeServiceImpl;

public class ClientEmployee {

	public static void main(String[] args) {
		Employee employee = new Employee(10,"pqr",500000);
		EmployeeService empService = new EmployeeServiceImpl();
		empService.insertEmployee(employee);
		employee.setSalary(60000);
		empService.updateEmployee(employee);
		List<Employee>employeeList = empService.viewEmployee();
		System.out.println("All records: ");
		for(Employee e:employeeList)
		{
			System.out.println(e);
		}
		empService.deleteEmployee(10);
		
		employeeList = empService.viewEmployee();
		System.out.println("All records: ");
		for(Employee e:employeeList)
		{
			System.out.println(e);
		}

	}

}
