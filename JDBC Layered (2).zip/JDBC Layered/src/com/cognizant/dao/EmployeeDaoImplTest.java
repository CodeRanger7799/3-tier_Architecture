package com.cognizant.dao;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.cognizant.exception.EmployeeException;
import com.cognizant.model.Employee;

public class EmployeeDaoImplTest {
	private EmployeeDao employeeDao;
	@Before
	public void setUp() throws Exception {
		employeeDao = new EmployeeDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		employeeDao = null;
	}

	@Test
	public final void testInsertEmployeePositive() {
		Employee employee = new Employee(4,"ajay",56000);
		int status = 0;
		try
		{
			status = employeeDao.insertEmployee(employee);
		}catch(EmployeeException ee)
		{
			ee.printStackTrace();
		}
		assertTrue(status == 1);
		
	}
	//(expected=EmployeeException.class)
	@Ignore
	public final void testInsertEmployeeNegative() throws EmployeeException {
		Employee employee = new Employee(3,"xyz",31000);
		int status = 0;
		
			status = employeeDao.insertEmployee(employee);
		
		
		assertTrue(status == 1);
		
	}


	@Test
	public final void testUpdateEmployee() {
		Employee employee = new Employee(2,"xyz",21000);
		int status = 0;
		try
		{
			status = employeeDao.updateEmployee(employee);
		}catch(EmployeeException ee)
		{
			ee.printStackTrace();
		}
		assertTrue(status == 1);
	}

	@Test
	public final void testDeleteEmployee() {
	
		int status = 0;
		final int empid=2;
		try
		{
			status = employeeDao.deleteEmployee(empid);
		}catch(EmployeeException ee)
		{
			ee.printStackTrace();
		}
		assertTrue(status == 1);
	}

	@Test
	public final void testViewEmployee() {
		List<Employee>employeelist = null;
		try
		{
			employeelist = employeeDao.viewEmployee();
		}catch(EmployeeException ee)
		{
			ee.printStackTrace();
		}
		assertTrue(employeelist.size()>0);
	}
	}


