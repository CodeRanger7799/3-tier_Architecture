package com.cognizant.truyum.dao;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImplTest {
	private MenuItemDao menuItemDao;

	@Before
	public void setUp() throws Exception {
		menuItemDao = new MenuItemDaoCollectionImpl();
	}

	@After
	public void tearDown() throws Exception {
		menuItemDao = null;
	}

	@Ignore
	public final void testMenuItemDaoCollectionImp() {
		
	}

	@Test
	public final void testGetMenuItemListAdmin() {
		List<MenuItem> menuItemList = new ArrayList<MenuItem>();
		menuItemList = menuItemDao.getMenuItemListAdmin();
		menuItemList.forEach((n) -> System.out.println(n));
		
	}

	@Test
	public final void testGetMenuItemListCustomer() {
		List<MenuItem> menuItemList = new ArrayList<MenuItem>();
		menuItemList = menuItemDao.getMenuItemListCustomer();
		menuItemList.forEach((n)-> System.out.println(n));
		
	}

	@Test
	public final void testModifyMenuItem() {
		MenuItem mModify = new MenuItem(2,"Zinger-Burger",120.00f,true,DateUtil.convertToDate("15/03/2017"),"Starter",true);
		menuItemDao.modifyMenuItem(mModify);
		System.out.println(menuItemDao.getMenuItem(2));
		
	}

	@Test
	public final void testGetMenuItem() {
		System.out.println(menuItemDao.getMenuItem(5));
	}

}
