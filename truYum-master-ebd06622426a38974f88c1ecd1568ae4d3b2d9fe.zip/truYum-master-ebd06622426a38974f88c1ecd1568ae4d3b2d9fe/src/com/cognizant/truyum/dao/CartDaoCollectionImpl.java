package com.cognizant.truyum.dao;

import java.util.HashMap;
import java.util.List;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImpl implements CartDao {
	private static HashMap<Long,Cart> userCart;

	public CartDaoCollectionImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addCartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<MenuItem> getAllCartItems(long userId) throws cartEmptyException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeCartItems(long userId, long menuItemId) {
		// TODO Auto-generated method stub

	}

}
