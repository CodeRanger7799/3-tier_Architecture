package com.cognizant.truyum.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CartDaoCollectionImplTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testCartDaoCollectionImpl() {
		fail("Not yet implemented");
	}

	@Test
	public final void testAddCartItem() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetAllCartItems() {
		fail("Not yet implemented");
	}

	@Test
	public final void testRemoveCartItems() {
		fail("Not yet implemented");
	}

}
