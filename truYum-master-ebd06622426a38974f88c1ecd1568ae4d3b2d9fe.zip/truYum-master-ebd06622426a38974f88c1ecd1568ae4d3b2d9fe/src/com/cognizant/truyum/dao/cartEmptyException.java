package com.cognizant.truyum.dao;

public class cartEmptyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -765553139829398374L;

	public cartEmptyException() {
		// TODO Auto-generated constructor stub
	}

	public cartEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public cartEmptyException(Throwable message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public cartEmptyException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public cartEmptyException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
