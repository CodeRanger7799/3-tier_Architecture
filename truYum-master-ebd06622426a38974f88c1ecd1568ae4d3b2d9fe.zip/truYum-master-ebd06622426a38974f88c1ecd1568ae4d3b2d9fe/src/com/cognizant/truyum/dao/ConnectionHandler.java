package com.cognizant.truyum.dao;

import java.sql.Connection;

public class ConnectionHandler {

	public ConnectionHandler() {
		// TODO Auto-generated constructor stub
	}
	
	public static Connection getConnection()
	{
		Connection conn = null;
		return conn;
	}

}
